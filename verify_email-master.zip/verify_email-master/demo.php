<?php
function validateEmailDomain($email) {
    $domain = substr(strrchr($email, "@"), 1);
    return checkdnsrr($domain, "MX");
}

// Example usage
$email = "example@gmail.com";
if (validateEmailDomain($email)) {
    echo "Domain has valid MX records";
} else {
    echo "Invalid domain or no MX records found";
}
?>
