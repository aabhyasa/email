<?php
// Only handle POST requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])) {
    // Start the timer
    $startTime = microtime(true);

    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    header('Content-Type: application/json');

    // Initialize results array
    $results = [];

    // Step 1: Syntax Validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $results[] = ['step' => 'Syntax Validation', 'status' => 'danger', 'result' => 'Invalid', 'message' => 'Invalid email format.'];
        // Calculate time
        $timeTaken = microtime(true) - $startTime;
        echo json_encode(['steps' => $results, 'result' => 'Invalid', 'time' => round($timeTaken, 4) . ' seconds']);
        exit();
    } else {
        $results[] = ['step' => 'Syntax Validation', 'status' => 'success', 'result' => 'Valid', 'message' => 'Valid email syntax: ' . $email];
    }

    // Extract the domain part from the email
    list($localPart, $domainPart) = explode('@', $email);

    // Step 2: DNS MX Lookup
    if (!checkdnsrr($domainPart, 'MX')) {
        if (!checkdnsrr($domainPart, 'A')) {
            $results[] = ['step' => 'DNS MX Lookup', 'status' => 'danger', 'result' => 'Invalid', 'message' => 'The domain does not have valid MX or A records.'];
            // Calculate time
            $timeTaken = microtime(true) - $startTime;
            echo json_encode(['steps' => $results, 'result' => 'Invalid', 'time' => round($timeTaken, 4) . ' seconds']);
            exit();
        } else {
            $results[] = ['step' => 'DNS MX Lookup', 'status' => 'success', 'result' => 'Valid', 'message' => 'Valid A record found for ' . $domainPart];
        }
    } else {
        $results[] = ['step' => 'DNS MX Lookup', 'status' => 'success', 'result' => 'Valid', 'message' => 'Valid MX records found for ' . $domainPart];
    }

    // Step 3: SMTP Server Connection
    $smtpValidation = validateSMTP($email, $domainPart);
    if ($smtpValidation['status'] == 'valid') {
        $results[] = ['step' => 'SMTP Server Connection', 'status' => 'success', 'result' => 'Valid', 'message' => 'SMTP connection successful for ' . $domainPart];
    } else {
        $results[] = ['step' => 'SMTP Server Connection', 'status' => 'danger', 'result' => 'Invalid', 'message' => $smtpValidation['message']];
        // Calculate time
        $timeTaken = microtime(true) - $startTime;
        echo json_encode(['steps' => $results, 'result' => 'Invalid', 'time' => round($timeTaken, 4) . ' seconds']);
        exit();
    }

    // Step 4: Mailbox Validation
    $mailboxValidation = validateMailbox($email, $domainPart);
    if ($mailboxValidation['status'] == 'valid') {
        $results[] = ['step' => 'Mailbox Validation', 'status' => 'success', 'result' => 'Valid', 'message' => 'Mailbox exists for ' . $email];
    } else {
        $results[] = ['step' => 'Mailbox Validation', 'status' => 'danger', 'result' => 'Invalid', 'message' => $mailboxValidation['message']];
    }

    // Step 5: Honeypot and Disposable Address Check
    $honeypotCheck = checkHoneypot($email);
    $disposableCheck = checkDisposable($email);
    if ($honeypotCheck) {
        $results[] = ['step' => 'Honeypot Check', 'status' => 'danger', 'result' => 'Invalid', 'message' => 'The email address is a known honeypot (spamtrap).'];
    } else {
        $results[] = ['step' => 'Honeypot Check', 'status' => 'success', 'result' => 'Valid', 'message' => 'The email address is not a known honeypot.'];
    }

    if ($disposableCheck) {
        $results[] = ['step' => 'Disposable Address Check', 'status' => 'danger', 'result' => 'Invalid', 'message' => 'The email address is a known disposable address.'];
    } else {
        $results[] = ['step' => 'Disposable Address Check', 'status' => 'success', 'result' => 'Valid', 'message' => 'The email address is not a known disposable address.'];
    }

    // Calculate the total time taken for processing
    $timeTaken = microtime(true) - $startTime;
    echo json_encode(['steps' => $results, 'result' => 'Valid', 'time' => round($timeTaken, 4) . ' seconds']);
    exit();
}

// SMTP Validation Function
function validateSMTP($email, $domain) {
    $mxHosts = [];
    getmxrr($domain, $mxHosts);

    if (empty($mxHosts)) {
        $aRecord = gethostbyname($domain);
        if ($aRecord == $domain) {
            return ['status' => 'invalid', 'message' => "Failed to connect to A record of $domain."];
        }
        $mxHosts[] = $aRecord;
    }

    foreach ($mxHosts as $mxHost) {
        $connection = @fsockopen($mxHost, 25);
        if ($connection) {
            fclose($connection);
            return ['status' => 'valid', 'message' => "SMTP server is reachable for domain $domain."];
        }
    }
    return ['status' => 'invalid', 'message' => "Failed to connect to SMTP server for $domain."];
}

// Mailbox Validation Function
function validateMailbox($email, $domain) {
    $mxHosts = [];
    getmxrr($domain, $mxHosts);

    if (empty($mxHosts)) {
        $aRecord = gethostbyname($domain);
        if ($aRecord != $domain) {
            $mxHosts[] = $aRecord;
        }
    }

    foreach ($mxHosts as $mxHost) {
        $connection = @fsockopen($mxHost, 25, $errno, $errstr, 10);
        if (!$connection) {
            return ['status' => 'invalid', 'message' => "Could not connect to mail server: $errstr ($errno)"];
        }

        fgets($connection);
        fputs($connection, "HELO example.com\r\n");
        fgets($connection);
        fputs($connection, "MAIL FROM: <test@example.com>\r\n");
        fgets($connection);
        fputs($connection, "RCPT TO: <$email>\r\n");
        $response = fgets($connection);
        fputs($connection, "QUIT\r\n");
        fclose($connection);

        if (strpos($response, '250') !== false) {
            return ['status' => 'valid', 'message' => "Mailbox exists for $email."];
        } elseif (strpos($response, '550') !== false) {
            return ['status' => 'invalid', 'message' => "Mailbox not found for $email."];
        }
    }

    return ['status' => 'invalid', 'message' => "Failed to validate mailbox for $email."];
}

// Honeypot Check Function
function checkHoneypot($email) {
    $honeypotEmails = ['spamtrap@example.com', 'trap@spamtrap.com']; // Add more as needed
    return in_array($email, $honeypotEmails);
}

// Disposable Email Check Function
function checkDisposable($email) {
    $disposableDomains = ['mailinator.com', 'tempmail.com', '10minutemail.com']; // Add more as needed
    list(, $domain) = explode('@', $email);
    return in_array($domain, $disposableDomains);
}

?>
