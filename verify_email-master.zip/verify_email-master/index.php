<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Validation with Progress Bar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 50%;
            margin: 100px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .container h1 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            color: #333;
            margin-bottom: 5px;
        }
        .form-group input[type="email"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .form-group input[type="submit"]:hover {
            background-color: #218838;
        }
        .result {
            margin-top: 20px;
        }
        .result .step {
            background-color: #f8f9fa;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
            border-left: 5px solid #28a745;
        }
        .result .step.invalid {
            border-left-color: #dc3545;
        }
        .progress-container {
            margin-top: 20px;
            width: 100%;
            background-color: #f3f3f3;
            border-radius: 4px;
            overflow: hidden;
            height: 20px;
        }
        .progress-bar {
            height: 100%;
            width: 0;
            background-color: #28a745;
            transition: width 0.5s;
        }
        label{
            font-weight:bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Email Validation</h1>
    <form id="emailValidationForm" method="post">
        <div class="form-group">
            <label for="email">Enter Email Address:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <input type="submit" value="Validate Email">
        </div>
    </form>

    <!-- Progress Bar -->
    <div class="progress-container" id="progressContainer" style="display: none;">
        <div class="progress-bar" id="progressBar"></div>
    </div>

    <div id="resultContainer" class="result"></div>
</div>

<script>
    document.getElementById('emailValidationForm').addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent form submission

        let formData = new FormData(this);
        let resultContainer = document.getElementById('resultContainer');
        let progressContainer = document.getElementById('progressContainer');
        let progressBar = document.getElementById('progressBar');

        // Reset results and progress bar
        resultContainer.innerHTML = '';
        progressBar.style.width = '0';
        progressContainer.style.display = 'block'; // Show progress bar

        // Simulate progress over 4 seconds (adjust as needed)
        let progress = 0;
        let progressInterval = setInterval(() => {
            progress += 10;
            progressBar.style.width = progress + '%';

            if (progress >= 100) {
                clearInterval(progressInterval); // Stop progress when complete
            }
        }, 400); // 400ms interval for each step

        // Fetch data from the backend
        fetch('validate.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            clearInterval(progressInterval); // Stop progress when fetch completes
            progressBar.style.width = '100%'; // Complete progress bar

            if (data.steps) {
                data.steps.forEach(step => {
                    let stepDiv = document.createElement('div');
                    stepDiv.className = 'step';
                    stepDiv.innerHTML = `<strong>${step.step}</strong>: ${step.message}`;
                    if (step.status === 'danger') {
                        stepDiv.classList.add('invalid');
                    }
                    resultContainer.appendChild(stepDiv);
                });

                let timeDiv = document.createElement('div');
                timeDiv.className = 'step';
                timeDiv.innerHTML = `<strong>Time Taken</strong>: ${data.time}`;
                resultContainer.appendChild(timeDiv);
            }
            progressContainer.style.display = 'none'; // Hide progress bar after completion
        })
        .catch(error => console.error('Error:', error));
    });
</script>

</body>
</html>
